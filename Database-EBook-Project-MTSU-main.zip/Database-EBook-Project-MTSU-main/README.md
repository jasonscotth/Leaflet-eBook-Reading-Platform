# Database-EBook-Project-leaflet.
### by Yi Zhou, Scott Hartsell, Hank Bennett, Mateo Lopez Moncaleano
In order to run this website you need XAMPP v3.3.0.
First start Apache and MySQL servers in XAMPP.
Second admin the MySQL server in XAMPP and import the file Create&LoadDB.sql.
Third delete the default index in the htdocs folder from XAMPP and then paste index.php and the folder leaflet.
Now just run the website using either localhost or admin for Apache in XAMPP.
